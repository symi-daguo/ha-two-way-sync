"""Application credentials platform for ha_two_way_sync."""
# This file exists to prevent Home Assistant from trying to load
# application_credentials platform that doesn't exist for this integration.
# The integration doesn't use application credentials.